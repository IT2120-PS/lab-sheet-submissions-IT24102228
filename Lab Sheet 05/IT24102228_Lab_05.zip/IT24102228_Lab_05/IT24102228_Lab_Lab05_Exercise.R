## 1)
Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE,sep = ",")

## 2)
breaks <- seq(20, 70, length.out = 10)    #Define breaks for right-open intervals
hist(Delivery_Times$Delivery_Time_.minutes.,breaks = breaks, main = "Histogram of Delivery Times",right = FALSE,xlab = "Delivery Time", ylab = "Frequency")


## 3)
# The histogram is uni modal, centered roughly around 37–42.  


## 4)
upper_bounds <- breaks[-1]
hist_obj <- hist(Delivery_Times$Delivery_Time_.minutes., breaks = breaks, right = FALSE, plot = FALSE)

cum_freq <- cumsum(hist_obj$counts)
length(cum_freq) == length(upper_bounds)
plot(upper_bounds,cum_freq,  type = "o",col = "blue", main = "Cumulative Frequency Polygon (Ogive)", xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency")