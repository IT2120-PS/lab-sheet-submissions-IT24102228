## 1) 
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")

fix(Delivery_Times)   # close this window before running the rest
attach(Delivery_Times)

## 2) Histogram: 9 classes, 20 to 70, right-open
hist_ex <- hist(
  Delivery_Times$Delivery_Time_.minutes.,
  main   = "Histogram of Delivery Times",
  xlab   = "Time",
  breaks = seq(20, 70, length = 10),  # 9 classes
  right  = FALSE
)

## 3) No extreme outliers; range is 20 to 67 minutes.

## 4) 
freq_ex   <- hist_ex$counts
breaks_ex <- hist_ex$breaks
cum_ex    <- cumsum(freq_ex)

ogive_y <- c()
for (i in 1:length(breaks_ex)) {
  if (i == 1) ogive_y[i] <- 0 else ogive_y[i] <- cum_ex[i - 1]
}
plot(breaks_ex, ogive_y, type = 'l',
     main = "Ogive of Delivery Times",
     xlab = "Time", ylab = "Cumulative Frequency",
     ylim = c(0, max(cum_ex)))
cbind(Upper = breaks_ex, CumFreq = ogive_y)