##Importing the data set
data <- read.table("Data.txt",header=TRUE, sep = ",")

##view the file in a separate window
fix(data)
#Close the data window before you run the rest of the commands.
#Unless rest of the commands won't run.

##Attach the file into R. So, you can call the variables by their names.
attach (data)

##Part 1
##Rename the variables (column headings) of the data set as X1 and X2
names (data) <- c("X1","X2")
fix(data)

##Attach the file into R again as we renamed the variables.
attach (data)

##Obtain histogram for number of shareholders
hist(X2,main="Histogram for Number of Shareholders", breaks = seq(130,270, length = 8), right = FALSE)

##Part 2
##Using "breaks" command we can define number of classes we need in the histogram
##along with lower limit and upper limit.
##Using "right" command we can define whether classes have closed intervals or open intervals.
histogram <- hist(X2,main="Histogram for Number of Shareholders",breaks = seq(130, 270, length = 8), right = FALSE)
##Check how each argument inside "hist" command works using "help" command as follows
?hist


##Part 3
##Assign class limits of the frequency distribution into a variable called "breaks"
breaks <- round(histogram$breaks) # Round break point and rounded value assign to breaks that gives the nearest integer value
breaks
##Assign class frequencies of the histogram into a variable called "freq"
freq <- histogram$counts
freq
##Assign mid point of each class into a variable called "mids"
mids <- histogram$mids
mids

##Creating the variable called "Classes" for the frequency distribution
classes <- c()

##Creating a "for" loop to assign classes of the frequency distribution into "Classes" variable crated above.
for(i in 1:length(breaks)-1){
  classes [i] <- paste0("[", breaks[i], ",", breaks [i+1], ")")
}
  
##Obtaining frequency distribution by combining the values of "Classes" & "freq" variables
##"cbind" command used to merge the columns with same length
cbind(Classes = classes, Frequency = freq)


##Part 4
##Draw frequency polygon to the same plot.
lines (mids, freq)

##Draw frequency polygon in a new plot.
plot(mids, freq, type = 'o', main = "Frequency Polygon for Shareholders",xlab = "Shareholders", ylab = "Frequency", ylim = c(0,max(freq)))

## Part 5
## Using "cumsum" command we can get cumulative frquencies
cum.freq <- cumsum(freq)

## Creating a null variable called "new"
new <- c()
## Using "for loop to store cumaulative frequencies in order to get the ogive
for(i in 1:length(breaks)){
  if(i==1){
    new[i] = 0
  }else{
    new[i] = cum.freq[i-1]
  }
}

## Draw cumulative frequency polygon in a new plot
plot(breaks, new, type = 'l', main = "Cumalative Frequency Polygon for shareholders",
     xlab = "Shareholders", ylab = "Cumalative Frequency", ylim = c(0,max(cum.freq)))
## Obtain upper limit of each class 
cbind(Upper = breaks, CumFreq = new) 