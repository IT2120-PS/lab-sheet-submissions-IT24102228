## Exercise - Question 01

# Part 1
# X has binomial distribution with n=50 and p=0.85

# Part 2
# Rearrangement: P(X >= 47) = 1 - P(X <= 46)
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)


## Exercise - Question 02

# Part 1
# X: Number of customer calls received in one hour

# Part 2
# X has Poisson distribution with lambda = 12

# Part 3
dpois(15, 12)

