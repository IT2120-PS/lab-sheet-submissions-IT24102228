## Part 1
## Importing the data set
data <- read.table("DATA 4.txt", header = TRUE, sep = " ")

## View the file in a separate window
fix(data)

## Attach the file into R so you can call the variables by their names
attach(data)

## Part 2
## Part(a)
## Obtaining Box Plots
boxplot(X1, main = "Box Plot for team attendance", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X2, main = "Box plot for Team Salary", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box plot for Years", outline = TRUE, outpch = 8, horizontal = TRUE)

## Obtaining Histogram
hist(X1, ylab = "Frequency", xlab = "Team Attendance", main = "Histogram for Team Attendance")
hist(X2, ylab = "Frequency", xlab = "Team Salary", main = "Histogram for Team Salary")
hist(X3, ylab = "Frequency", xlab = "Years", main = "Histogram for Years")

## Stem Leaf Plot
stem(X1)
stem(X2)
stem(X3)

## Part(b)
## Mean
mean(X1)
mean(X2)
mean(X3)

## Median
median(X1)
median(X2)
median(X3)

## Standard Deviation
sd(X1)
sd(X2)
sd(X3)

## Part(c)
## Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)

## Getting only five number summary for X1 variable
quantile(X1)

## Calling first Quantile of X1 using index value
quantile(X1)[2]

## Calling third Quantile of X1 using index value
quantile(X1)[4]

## Part(d)
## Obtaining Inter Quantile Range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)

## Part 3
## Function to get the mode a data set
get.mode <- function(y) {
  counts <- table(y)  # Create frequency table from the input y
  names(counts[counts == max(counts)])  # Return value(s) with maximum frequency
}

## Example: Obtaining the mode of a variable using the function defined above
get.mode(X3)

## Explanation on how each command inside the function works

## The following command creates a frequency table for the variable X3
counts <- table(X3)
counts  # This will print the frequency table

## The following command gives the maximum frequency in the frequency table
max(counts)  # This works now because 'counts' has been defined

## The following command identifies which value(s) have that maximum frequency
counts == max(counts)

## The following command extracts the value(s) with the highest frequency
counts[counts == max(counts)]

## The following command gets the names (i.e., the values themselves) of those most frequent entries
names(counts[counts == max(counts)])

## Part 4
## Function to check existence outliers of a data set
get.outliers <- function(z){
  q1 <- quantile(z) [2]
  q3 <- quantile(z) [4]
  iqr <- q3 -q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers", paste(sort(z[z < lb | z > ub]), collapse = ",")))
}

## Checking the outliers of a variable using the function defined above
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)

## Explanantion on how each command inside the function works
## Following command is to calculate the interval for outliers
get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  ## Following command to display upper boundary and lower boundary of the interval
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound =", lb))
  
  ## Checking existence of outliers and display the outliers if exists
  print(paste("Outliers", paste(sort(z[z < lb|z > ub]),collapse = ",")))
}

## EXCERCISE

# 1) Import the dataset into a data frame called branch_data
branch_data <- read.table('Exercise.txt', header=TRUE, sep=',')
names(branch_data) <- c("Branch","Sales_X1","Advertising_X2","Years_X3")


# 2) Identify the variable type and scale of measurement for each variable.
attach(branch_data)
for(col in names(branch_data)){
  print(paste(col,":",class(branch_data[[col]])))
}

# 3) Boxplot for Sales
boxplot(branch_data$Sales_X1, horizontal=TRUE, main="Boxplot of Sales (X1)", xlab="Sales")

# 4) Five-number summary and IQR for Advertising
summary(Advertising_X2)
quantile(Advertising_X2)
IQR(Advertising_X2)

# 5) Function to find outliers in a numeric vector and check for Years
get.outliers <- function(x) {
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  lb <- q1 - 1.5*iqr
  ub <- q3 + 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers", paste(sort(x[x < lb | x > ub]), collapse = ",")))
}

get.outliers(Years_X3)

